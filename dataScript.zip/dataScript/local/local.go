package local

import (
	"fmt"
	"github.com/xuri/excelize/v2"
	"os"
	"test/dataScript/dao"
	"test/dataScript/format"
)

func ReadLocalData(param format.FileData, db interface{}) {
	file, err := os.Open(param.Content.Read.Link)
	if err != nil {
		fmt.Println("读取本地文件失败：", err)
		return
	}
	defer file.Close()

	excelFile, err := excelize.OpenReader(file)
	sheetName := excelFile.GetSheetList()
	if len(sheetName) == 0 {
		return
	}
	rows, err := excelFile.GetRows(sheetName[0])
	if err != nil {
		fmt.Println("读取本地文件失败：", err)
		return
	}
	dao.DataInsert(param.Content.Read.Column, param.Content.Read.DelColumn, rows, param.Content.Write.Table, db)
}
