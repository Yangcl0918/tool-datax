package dao

import (
	"bytes"
	"fmt"
	"github.com/gin-gonic/gin"
	"strings"
	"test/dataScript/database"
)

func DataInsert(columns, delColumns []string, rows [][]string, table string, dbPtr interface{}) {
	if len(rows) == 0 {
		return
	}
	indexMap := map[string]int{}
	for k, v := range rows[0] {
		indexMap[v] = k
	}

	sql := fmt.Sprintf("insert into %s (%s) values", table, strings.Join(columns, ","))
	insertSuf := fmt.Sprintf("(%s)", CreateQuestionMarks(len(columns)))
	insSufAry, delSufAry, values := []string{}, []string{}, []interface{}{}
	for k, row := range rows {
		if k == 0 {
			continue
		}
		insSufAry = append(insSufAry, insertSuf)
		for _, v := range columns {
			values = append(values, row[indexMap[v]])
		}
		delAry := []string{}
		for _, v := range delColumns {
			delAry = append(delAry, fmt.Sprintf("`%s` = '%s'", v, row[indexMap[v]]))
		}
		if len(delAry) > 0 {
			delSufAry = append(delSufAry, "("+strings.Join(delAry, " and ")+")")
		}
	}

	if len(delSufAry) > 0 {
		delSql := fmt.Sprintf("delete from %s where %s", table, strings.Join(delSufAry, " or "))
		_, err := database.ExecSqlCtx(&gin.Context{}, dbPtr, delSql)
		if err != nil {
			fmt.Println("数据删除失败：", err)
			return
		}
	}
	if len(insSufAry) > 0 {
		sql += strings.Join(insSufAry, ",")
		_, err := database.ExecSqlCtx(&gin.Context{}, dbPtr, sql, values...)
		if err != nil {
			fmt.Println("数据插入失败：", err)
			return
		}
	}
}

// CreateQuestionMarks 预执行占位符"?"生成
// @usage utils.CreateQuestionMarks(3)  --> ?,?,?
func CreateQuestionMarks(n int) string {
	if n <= 0 {
		return ""
		// } else if n > 65536 { // todo 太大是否需要警告
	}
	var buf bytes.Buffer
	buf.WriteString("?")
	for i := 1; i < n; i++ {
		buf.WriteString(",?")
	}
	return buf.String()
}
