package database

import (
	"cloud.google.com/go/bigquery"
	"database/sql"
	logging "e.coding.intlgame.com/partner/dic-framework/zaplog"
	"errors"
	"strconv"
	"strings"
	"sync"

	_ "github.com/go-sql-driver/mysql"
	_ "github.com/lib/pq"
)

// 经分游戏业务相关信息，
type gameInfo struct {
	code   string // code是存储db的map中key
	driver string // 表示数据库类型，如postgres，clickhouse
	sqlVer string // 因为兼容新老框架两套数据表，v1和v2，现在PC经分暂时只考虑v2
	schema string // 游戏数据是按照schema分类存储
}

// db Handle map
var (
	dbh  map[string]*sql.DB
	bqh  map[string]*bigquery.Client
	lock sync.Mutex
)

// game gdmap map
var (
	gdmap map[string]gameInfo
)

// 关闭DB Handle
func DBProxyClose() {
	for _, db := range dbh {
		db.Close()
	}
}

func GetDBSchemaHandleByKey(key string) (*sql.DB, error) {
	if db, ok := dbh[key]; ok {
		return db, nil
	}
	return nil, errors.New("not found db handle")
}

// GetDBSchemaHandle
// @Title 获取DB Handle增加schema
// @Description
//
//	7/14 jason需求，数据库增加schema
//
// @Author lxy
// @Update 2021/07/14
func GetDBSchemaHandle(gameCode string) (db *sql.DB, driver string, sqlVer string, schema string, err error) {

	phase := GetDefaultPhase(gameCode)

	ident := gdmap[gameCode+":"+phase].code
	logging.InfoF("ident:%s", ident)
	// 游戏没有配置其他阶段的数据库
	if ident == "" {
		// 系统如果配置了默认使用的数据库，则使用该数据库
		if dbh["default_db"] != nil {
			logging.InfoF("use default_db")
			db = dbh["default_db"]
			driver = "postgres"
			sqlVer = "v2"
			schema = gameCode
			return
		}
		// 没有找到与此游戏匹配的数据库也没有默认数据库，返回错误
		err = errors.New("not found game code map")
		return
	}

	db = dbh[ident]
	driver = gdmap[gameCode+":"+phase].driver
	sqlVer = gdmap[gameCode+":"+phase].sqlVer
	schema = gdmap[gameCode+":"+phase].schema
	if db == nil {
		err = errors.New("not found db handle")
	}
	return
}

// 查询实时数据表，获取DB信息
func GetRealtimeDBSchemaHandle(gameCode string) (db *sql.DB, driver string, sqlVer string, schema string, err error) {

	phase := GetDefaultPhase(gameCode)

	var realtimeDB gameInfo
	if _, ok := gdmap[gameCode+":"+phase+":realtime"]; ok {
		realtimeDB = gdmap[gameCode+":"+phase+":realtime"]
	} else {
		// realtimeDB = gdmap[gameCode+":"+phase]
		db, driver, sqlVer, schema, err = GetDBSchemaHandle(gameCode)
		return
	}
	ident := realtimeDB.code
	if ident == "" {
		err = errors.New("not found game code map")
	}
	db = dbh[ident]
	driver = realtimeDB.driver
	sqlVer = realtimeDB.sqlVer
	schema = realtimeDB.schema
	if db == nil {
		err = errors.New("not found db handle")
	}
	return
}

// 查询PCU数据表，获取DB信息
func GetPcuDBSchemaHandle(gameCode string) (db *sql.DB, driver string, sqlVer string, schema string, err error) {

	phase := GetDefaultPhase(gameCode)

	var pcuDB gameInfo
	if _, ok := gdmap[gameCode+":"+phase+":pcu"]; ok {
		pcuDB = gdmap[gameCode+":"+phase+":pcu"]
	} else {
		db, driver, sqlVer, schema, err = GetRealtimeDBSchemaHandle(gameCode)
		return
	}
	ident := pcuDB.code
	if ident == "" {
		err = errors.New("not found game code map")
	}
	db = dbh[ident]
	driver = pcuDB.driver
	sqlVer = pcuDB.sqlVer
	schema = pcuDB.schema
	if db == nil {
		err = errors.New("not fodb handle")
	}
	return
}

func GetPVPInfoDatabase(gameCode string) (*sql.DB, error) {
	dbName := gdmap[gameCode+":pvp_info"].code
	if dbName == "" {
		return nil, errors.New("未配置PVP过程对局信息数据库")
	}
	return dbh[dbName], nil
}

// 初始化数据库代理, 并从数据库中加载DB配置
func SetupDBProxy() {
	if dbh != nil {
		logging.InfoF("关闭现有数据库连接, %v", dbh)
		DBProxyClose()
	}
	dbh = make(map[string]*sql.DB)
	logging.InfoF("--------------------开始加载DB配置--------------------")
	selectSql := "select ident, driver, db, user, password, endpoint, port, max_open_conns, max_idle_conns from t_dashboard_db_config"
	result, err := SelectQuery(MysqlDB, selectSql)
	if err != nil {
		logging.WarnF("读取数据库配置错误: %s", err)
	}
	//遍历数据库源
	for _, item := range result {
		if len(item["ident"]) > 0 {
			//构建数据源连接字符串
			var connStr string
			//通过driver字段, 判断数据源类型
			switch item["driver"] {
			case "postgres":
				{
					connStr = `host=` + item["endpoint"] + ` port=` + item["port"] + ` user=` + item["user"] + ` password=` + item["password"] + ` dbname=` + item["db"] + ` sslmode=disable`
				}
			case "clickhouse":
				{
					//connStr = `tcp://` + item["endpoint"] + `:` + item["port"] + `?username=` + item["user"] + `&password=` + item["password"] + `&database=` + item["db"] + `&compress=true&debug=false`
					connStr = `tcp://` + item["endpoint"] + `:` + item["port"] + `?username=` + item["user"] + `&database=` + item["db"] + `&compress=true&debug=false`
				}
			default:
				{
					item["driver"] = "mysql"
					connStr = item["user"] + `:` + item["password"] + `@tcp(` + item["endpoint"] + `:` + item["port"] + `)/` + item["db"]
				}
			}
			logging.InfoF("Loading Connect To: %s ", item["ident"])

			//建立数据库连接
			db, err := sql.Open(item["driver"], connStr)
			if err != nil {
				logging.WarnF("DB[%s] Connect Failed [%s]: %v", item["ident"], connStr, err)
				continue
			}

			//Ping数据库
			if err = db.Ping(); err != nil {
				logging.WarnF("DB[%s] Ping Failed [%s]: %v", item["ident"], connStr, err)
				continue
			}

			//判断是否已存在
			if _, ok := dbh[item["ident"]]; ok {
				logging.WarnF("ProxyDB Handle Has Being Covered: [%s] ", item)
			}
			dbh[item["ident"]] = db

			logging.InfoF("DB[ident:%s, driver:%s, ip:%s:%s, db:%s] Connect Succeed.", item["ident"], item["driver"], item["endpoint"], item["port"], item["db"])

			openconns, _ := strconv.Atoi(item["max_open_conns"])
			//设置最大连接数
			if openconns != 0 {
				dbh[item["ident"]].SetMaxOpenConns(openconns)
			}
			idleconns, _ := strconv.Atoi(item["max_idle_conns"])
			//设置最大空闲连接数
			if idleconns != 0 {
				dbh[item["ident"]].SetMaxIdleConns(idleconns)
			}

		} else {
			logging.WarnF("Load DB Handle Not Found Ident: ", item)
		}
	}

	logging.InfoF("dbProxy count is %d", len(dbh))

	//获取game code和db关系
	selectSql = "select g.game_code,g.phase_type,d.ident,d.driver,g.sql_version,g.schema, g.data_type from t_dashboard_tencent_game_db_map_pc  g left join t_dashboard_db_config d on g.db_ident = d.ident"
	result, err = SelectQuery(MysqlDB, selectSql)

	//初始化map
	gdmap = make(map[string]gameInfo)
	for _, dbMap := range result {
		gameInfo := gameInfo{code: dbMap["ident"], driver: dbMap["driver"], sqlVer: dbMap["sql_version"], schema: dbMap["schema"]}
		// 同个游戏的不同类型数据可能要从不同的数据库中读取
		dataType := strings.TrimSpace(dbMap["data_type"])
		if dataType != "" {
			if dataType == "ua" {
				gdmap[dbMap["game_code"]+":"+dbMap["data_type"]] = gameInfo
				continue
			} else if dataType == "pvp_info" {
				gdmap[dbMap["game_code"]+":"+"pvp_info"] = gameInfo
				continue
			} else {
				gdmap[dbMap["game_code"]+":"+dbMap["phase_type"]+":"+dbMap["data_type"]] = gameInfo
				continue
			}
		}
		gdmap[dbMap["game_code"]+":"+dbMap["phase_type"]] = gameInfo
	}

	logging.InfoF("--------------------完成加载DB配置--------------------")
	// for k := range dbh {
	// 	logging.InfoF(fmt.Sprintf("db---%s:,%+v", k, dbh))
	// 	logging.InfoF(fmt.Sprintf("gdmap---%+v", gdmap))
	// }
}

// 因为从移动版本移植而来，移动版本支持按照游戏发行阶段分DB，所以这里没有直接去掉，而是按照GL、SL、CBT的顺序去取 added by jasonzxyin
func GetDefaultPhase(gameCode string) string {

	phase := "CBT"
	if _, ok := gdmap[gameCode+":GL"]; ok {
		phase = "GL"
	} else if _, ok := gdmap[gameCode+":SL"]; ok {
		phase = "SL"
	}

	return phase

}

// GetDB 获取连接池对象
func GetDB(ident string) *sql.DB {
	lock.Lock()
	defer lock.Unlock()
	if db, ok := dbh[ident]; ok {
		return db
	}
	return nil
}

// AddDB 添加连接池对象
func AddDB(ident string, db *sql.DB) {
	lock.Lock()
	defer lock.Unlock()
	if dbh == nil {
		dbh = make(map[string]*sql.DB, 0)
	}
	dbh[ident] = db
}

// AddDB 添加连接池对象
func AddBQ(ident string, bq *bigquery.Client) {
	lock.Lock()
	defer lock.Unlock()
	if bqh == nil {
		bqh = make(map[string]*bigquery.Client, 0)
	}
	bqh[ident] = bq
}

// GetBQ 获取连接池对象
func GetBQ(ident string) *bigquery.Client {
	lock.Lock()
	defer lock.Unlock()
	if bq, ok := bqh[ident]; ok {
		return bq
	}
	return nil
}

// DelBQ 删除连接池对象
func DelBQ(ident string) {
	lock.Lock()
	defer lock.Unlock()
	delete(bqh, ident)
}
