package remote

import "test/dataScript/format"

type Link interface {
	GetData(param format.FileData, db interface{})
}
