package format

type FileData struct {
	Content Content `json:"content"`
}

type Content struct {
	Read  Read  `json:"read"`
	Write Write `json:"write"`
}

type Read struct {
	FileType   string   `json:"file_type"`
	Link       string   `json:"link"`
	LinkHeader []string `json:"link_header"`
	LinkMethod string   `json:"link_method"`
	Column     []string `json:"column"`
	DelColumn  []string `json:"delete_column"`
	RemoteType string   `json:"remote_type"`
}

type Write struct {
	Driver   string   `json:"driver"`
	Table    string   `json:"table"`
	Database Database `json:"database"`
}

type Database struct {
	Host     string `json:"host"`
	Port     string `json:"port"`
	UserName string `json:"user_name"`
	Password string `json:"password"`
	Schema   string `json:"schema"`
}
