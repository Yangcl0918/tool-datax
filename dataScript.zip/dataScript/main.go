package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"strings"
	"test/dataScript/database"
	"test/dataScript/format"
	"test/dataScript/local"
	"test/dataScript/remote"
)

var filePath = flag.String("f", "", "文件路径（绝对路径）")
var help = flag.String("example", "", `
本地配置文件示例：
{
    "content":{
        "read":{
            "file_type":"local",  该项写死为本地
            "remote_type": "",  本地该项可置空 
            "link":"./areyouok.xlsx", 要读取的本地excel文件表格路径（最好给绝对路径）
            "link_header":[""],  本地可忽略该项
            "link_method":"GET", 本地可忽略该项
            "column": ["env", "location", "dag_id", "task_id", "sla_time", "game_code", "dag_granularity", "type", "priority"], excel里要同步的字段名，注：字段名需与表字段名一致
            "delete_column": ["dag_id", "task_id"]   数据表内需要删除数据的 where 条件依据，如不需删除数据可忽略该项
        },
        "write":{
            "driver": "mysql",  数据库类型当前支持 bigquery、postgres、starrocks、mysql
            "table":"t_databrain_airflow_monitor_config", 要操作的表名
            "database":{
                "host":"127.0.0.1",
                "port":"3306",
                "user_name":"root",
                "password":"",
                "schema":"db_ieg_spider"
            }
        }
    }
}
`)

var helpRemote = flag.String("example_remote", "", `
远程配置文件示例：
{
    "content":{
        "read":{
            "file_type":"remote", 该项写死为远程
            "remote_type": "google", 该项输入远程对象，当前仅支持  google
            "link":"15SVRHyCGknQfEmM9Qs6POBJIp18Qmmdbmx9nMnQAXkM",  【google 远程文件id，注：记得给service account添加文件权限】
            "link_header":["CredentialsFile:./tencent-gcp-iegintl.json", "SheetName:工作表1"],  【google 消息头固定为这两个， CredentialsFile为授权json文件路径，SheetName就文件内要读取的sheet的名字】
            "link_method":"GET", 后备扩容字段，当前没用。
            "column": ["env", "location", "dag_id", "task_id", "sla_time", "game_code", "dag_granularity", "type", "priority"],
            "delete_column": ["dag_id", "task_id"]
        },
        "write":{
            "driver": "mysql",
            "table":"t_databrain_airflow_monitor_config",
            "database":{
                "host":"127.0.0.1",
                "port":"3306",
                "user_name":"root",
                "password":"",
                "schema":"db_ieg_spider"
            }
        }
    }
}
`)

func main() {
	flag.Parse()

	if *help != "" || *helpRemote != "" {
		fmt.Println(*help, *helpRemote)
		return
	}

	fmt.Println("开始")

	file, err := os.Open(*filePath)
	if err != nil {
		fmt.Println("配置文件读取失败:", err)
		return
	}
	defer file.Close()

	b, err := io.ReadAll(file)
	if err != nil {
		fmt.Println("配置文件内容读取失败:", err)
		return
	}

	var data format.FileData
	err = json.Unmarshal(b, &data)
	if err != nil {
		fmt.Println("配置文件内容反序列失败:", err)
		return
	}
	//fmt.Println(data)

	var db interface{}
	//创建链接
	switch data.Content.Write.Driver {
	case "bigquery":
		database.SetupBigqueryDB(data.Content.Write.Database.Password)
		db = database.BigqueryDB
	case "postgres":
		database.SetupPostgresDB(data.Content.Write.Database.Host, data.Content.Write.Database.Port, data.Content.Write.Database.UserName,
			data.Content.Write.Database.Password, data.Content.Write.Database.Schema)
		db = database.PostgresDB
	case "starrocks":
		database.SetupStarrocksDB(data.Content.Write.Database.Host, data.Content.Write.Database.Port, data.Content.Write.Database.UserName,
			data.Content.Write.Database.Password, data.Content.Write.Database.Schema)
		db = database.StarrocksDB
	default:
		database.SetupMysqlDB(data.Content.Write.Database.Host, data.Content.Write.Database.Port, data.Content.Write.Database.UserName,
			data.Content.Write.Database.Password, data.Content.Write.Database.Schema)
		db = database.MysqlDB
	}

	switch data.Content.Read.FileType {
	case "local":
		local.ReadLocalData(data, db)
	case "remote":
		switch strings.ToLower(data.Content.Read.RemoteType) {
		case "google":
			remote.NewGoogleRemote().GetData(data, db)
		}
	}

	fmt.Println("执行完成")
}
