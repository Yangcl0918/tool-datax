package database

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"reflect"
	"strconv"
	"strings"
	"time"

	"cloud.google.com/go/bigquery"
	"google.golang.org/api/iterator"

	"github.com/gin-gonic/gin"

	_ "github.com/go-sql-driver/mysql"

	_ "github.com/lib/pq"
)

var (
	PostgresDB  *sql.DB
	BigqueryDB  *bigquery.Client
	MysqlDB     *sql.DB
	StarrocksDB *sql.DB
)

func pingDB(db *sql.DB, dbname string) {
	if err := db.Ping(); err != nil {
		fmt.Println("Ping database:%s connection error: %v", dbname, err)
	}
}

// 新建DB连接
func SetupMysqlDB(host, port, userName, password, schema string) {
	var err error
	if MysqlDB, err = sql.Open("mysql", fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=true", userName, password, host, port, schema)); err != nil {
		log.Fatalf("database.SetupMysqlDB.Setup err: %v", err)
	}

	pingDB(MysqlDB, "mysql")
	MysqlDB.SetMaxOpenConns(10)
	MysqlDB.SetMaxIdleConns(5)
}

// 新建DB连接
func SetupStarrocksDB(host, port, userName, password, schema string) {
	var err error
	if StarrocksDB, err = sql.Open("mysql", fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8mb4&parseTime=true", userName, password, host, port, schema)); err != nil {
		log.Fatalf("database.SetupStarrocksDB.Setup err: %v", err)
	}

	pingDB(StarrocksDB, "starrocks")
	StarrocksDB.SetMaxOpenConns(10)
	StarrocksDB.SetMaxIdleConns(5)
}

func SetupPostgresDB(host, port, userName, password, schema string) {
	var err error
	log.Printf("SetupPostgresDB")
	if PostgresDB, err = sql.Open("postgres", fmt.Sprintf("host=%s user=%s password=%s dbname=%s port=%s sslmode=disable TimeZone=Asia/Shanghai",
		host, userName, password, schema, port)); err != nil {
		log.Fatalf("database.SetupPostgresDB.Setup err: %v", err)
	}
	pingDB(PostgresDB, "postgres")

	PostgresDB.SetMaxOpenConns(10)
	PostgresDB.SetMaxIdleConns(5)

}

func SetupBigqueryDB(password string) {
	var err error
	BigqueryDB, err = BigQueryConnect("databrain_bigquery", password)
	if err != nil {
		log.Fatalf("database.SetupBigqueryDB.Setup err: %v", err)
	}
}

// ------Prepare Start----------
// 使用 DbPrepare 之后一定要使用 defer stmt.Close() closes the statement.
func DbPrepare(db *sql.DB, sqlStmt string) (*sql.Stmt, error) {
	stmt, err := db.Prepare(sqlStmt)
	defer prePrint(&err, nil, sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("sql prepare %s failed: %s", sqlStmt, err.Error())
	}
	return stmt, nil
}

// 使用 DbPrepareCtx 之后一定要使用 defer stmt.Close() closes the statement.
func DbPrepareCtx(c *gin.Context, db *sql.DB, sqlStmt string) (*sql.Stmt, error) {
	stmt, err := db.Prepare(sqlStmt)
	defer prePrint(&err, c, sqlStmt)
	if err != nil {
		return nil, fmt.Errorf("sql prepare %s failed: %s", sqlStmt, err.Error())
	}
	return stmt, nil
}

// 入参 stmt 来自 DbPrepare 的返回值
func SelectQueryPrepare(stmt *sql.Stmt, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var (
		err     error
		columns []string
	)
	defer unifiedPrint(&err, nil, getSql(stmt), &results, &columns, now, args...)
	rows, err := stmt.Query(args...)
	if err != nil {
		return nil, fmt.Errorf("sql query %s failed: %s", "", err.Error())
	}
	defer rows.Close()

	// 获取字段名的string切片
	columns, err = rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("sql affect rows failed: %s", err.Error())
	}

	values := make([]sql.RawBytes, len(columns))
	scanArgs := make([]interface{}, len(values))
	for i := range values {
		scanArgs[i] = &values[i]
	}
	for rows.Next() {
		err = rows.Scan(scanArgs...)
		record := make(map[string]string)
		if err != nil {
			return nil, fmt.Errorf("rows scan failed: %s", err.Error())
		}
		for i, col := range values {
			value := string(col)
			record[columns[i]] = value
		}
		results = append(results, record)
	}
	return results, nil
}

// 入参 stmt 来自 DbPrepareCtx 的返回值
func SelectQueryPreCtx(c *gin.Context, stmt *sql.Stmt, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var (
		err     error
		columns []string
	)
	defer unifiedPrint(&err, c, getSql(stmt), &results, &columns, now, args...)

	rows, err := stmt.Query(args...)
	if err != nil {
		return nil, fmt.Errorf("sql query %s failed: %s", "", err.Error())
	}
	defer rows.Close()

	// 获取字段名的string切片
	columns, err = rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("sql affect rows failed: %s", err.Error())
	}

	values := make([]sql.RawBytes, len(columns))
	scanArgs := make([]interface{}, len(values))
	for i := range values {
		scanArgs[i] = &values[i]
	}
	for rows.Next() {
		err = rows.Scan(scanArgs...)
		record := make(map[string]string)
		if err != nil {
			return nil, fmt.Errorf("rows scan failed: %s", err.Error())
		}
		for i, col := range values {
			value := string(col)
			record[columns[i]] = value
		}
		results = append(results, record)
	}
	return results, nil
} // ------ Prepare End ----------

// added by jasonzxyin
// 修改内容：
// 1、不再使用prepare方式，因为sql相似性不大
// 2、设置某个超时时间，防止sql查询时间太长导致接口耗时过长
func SelectQueryWithTimeout(db *sql.DB, queryTimeoutMS int, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var (
		err     error
		columns []string
	)
	defer unifiedPrint(&err, nil, sqlStmt, &results, &columns, now, args...)
	// printArgs(sqlStmt, args...)
	var QueryCtx context.Context
	var cancel context.CancelFunc
	if queryTimeoutMS != 0 {
		QueryCtx, cancel = context.WithTimeout(context.Background(), time.Duration(queryTimeoutMS)*time.Millisecond)
		defer cancel() // releases resources if slowOperation completes before timeout elapses
	} else {
		QueryCtx = context.Background()
	}

	rows, err := db.QueryContext(QueryCtx, sqlStmt, args...)
	if err != nil {
		return nil, fmt.Errorf("sql query %s failed: %s", sqlStmt, err)
	}
	defer rows.Close()

	// 获取字段名的string切片
	columns, err = rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("sql affect rows failed: %s", err)
	}

	values := make([]sql.RawBytes, len(columns))
	scanArgs := make([]interface{}, len(values))
	for i := range values {
		scanArgs[i] = &values[i]
	}
	for rows.Next() {
		err = rows.Scan(scanArgs...)
		record := make(map[string]string)
		if err != nil {
			return nil, fmt.Errorf("rows Scan failed: %s", err)
		}
		for i, col := range values {
			value := string(col)
			record[columns[i]] = value
		}
		results = append(results, record)
	}

	return results, nil
}

func SelectQueryWithTimeoutCtx(c *gin.Context, db *sql.DB, queryTimeoutMS int, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	var QueryCtx context.Context
	var cancel context.CancelFunc
	results := make([]map[string]string, 0)
	var (
		err     error
		columns []string
	)
	defer unifiedPrint(&err, c, sqlStmt, &results, &columns, now, args...)

	if queryTimeoutMS != 0 {
		QueryCtx, cancel = context.WithTimeout(context.Background(), time.Duration(queryTimeoutMS)*time.Millisecond)
		defer cancel() // releases resources if slowOperation completes before timeout elapses
	} else {
		QueryCtx = context.Background()
	}

	rows, err := db.QueryContext(QueryCtx, sqlStmt, args...)
	if err != nil {
		return nil, fmt.Errorf("sql query %s failed: %s", sqlStmt, err)
	}
	defer rows.Close()

	// 获取字段名的string切片
	columns, err = rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("sql affect rows failed: %s", err)
	}

	values := make([]sql.RawBytes, len(columns))
	scanArgs := make([]interface{}, len(values))
	for i := range values {
		scanArgs[i] = &values[i]
	}
	for rows.Next() {
		err = rows.Scan(scanArgs...)
		record := make(map[string]string)
		if err != nil {
			return nil, fmt.Errorf("rows Scan failed: %s", err)
		}
		for i, col := range values {
			value := string(col)
			record[columns[i]] = value
		}
		results = append(results, record)
	}
	return results, nil
}

func SelectQuery(dbPtr interface{}, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var (
		err     error
		columns []string
	)
	defer unifiedPrint(&err, nil, sqlStmt, &results, &columns, now, args...)

	bqDB, ok := dbPtr.(*bigquery.Client)
	if ok {
		return bqSelect(bqDB, sqlStmt, args...)
	}

	db, ok := dbPtr.(*sql.DB)
	if !ok {
		return results, errors.New("error type dbPtr")
	}

	rows, err := db.Query(sqlStmt, args...)
	if err != nil {
		return nil, fmt.Errorf("sql query %s failed: %s", sqlStmt, err)
	}
	defer rows.Close()

	// 获取字段名的string切片
	columns, err = rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("sql affect rows failed: %s", err)
	}

	values := make([]sql.RawBytes, len(columns))
	scanArgs := make([]interface{}, len(values))
	for i := range values {
		scanArgs[i] = &values[i]
	}
	for rows.Next() {
		err = rows.Scan(scanArgs...)
		record := make(map[string]string)
		if err != nil {
			return nil, fmt.Errorf("rows Scan failed: %s", err)
		}
		for i, col := range values {
			value := string(col)
			record[columns[i]] = value
		}
		results = append(results, record)
	}
	return results, nil
}

func bqSelect(client *bigquery.Client, query string, args ...interface{}) ([]map[string]string, error) {
	for _, v := range args {
		val := ""
		switch reflect.TypeOf(v).Kind() {
		case reflect.Int:
			val = strconv.Itoa(v.(int))
			query = strings.Replace(query, "?", val, 1)
			continue
		case reflect.Int64:
			query = strings.Replace(query, "?", val, 1)
			val = strconv.FormatInt(v.(int64), 10)
			continue
		case reflect.String:
			val = v.(string)
		default:
			vb, _ := json.Marshal(v)
			val = string(vb)
		}
		query = strings.Replace(query, "?", fmt.Sprintf("'%s'", val), 1)
	}
	fmt.Println("exec bigquery query: %s, param: %v", query, args)
	q := client.Query(query)
	if client == nil {
		return nil, errors.New("client nil")
	}
	it, err := q.Read(context.Background())
	if err != nil {
		return nil, err
	}
	var results []map[string]string
	for {
		var row map[string]bigquery.Value
		err := it.Next(&row)
		if err == iterator.Done {
			break
		}
		if err != nil {
			return nil, err
		}
		result := make(map[string]string)
		for key, value := range row {
			result[key] = fmt.Sprintf("%v", value)
		}
		results = append(results, result)
	}
	return results, nil
}

func SelectQueryCtx(c *gin.Context, dbPtr interface{}, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var (
		err     error
		columns []string
	)
	defer unifiedPrint(&err, c, sqlStmt, &results, &columns, now, args...)

	bqDB, ok := dbPtr.(*bigquery.Client)
	if ok {
		return bqSelect(bqDB, sqlStmt, args...)
	}

	db, ok := dbPtr.(*sql.DB)
	if !ok {
		return results, errors.New("error type dbPtr")
	}

	rows, err := db.Query(sqlStmt, args...)
	if err != nil {
		return nil, fmt.Errorf("sql query %s failed: %s", sqlStmt, err)
	}
	defer rows.Close()

	// 获取字段名的string切片
	columns, err = rows.Columns()
	if err != nil {
		return nil, fmt.Errorf("sql affect rows failed: %s", err)
	}

	values := make([]sql.RawBytes, len(columns))
	scanArgs := make([]interface{}, len(values))
	for i := range values {
		scanArgs[i] = &values[i]
	}
	for rows.Next() {
		err = rows.Scan(scanArgs...)
		record := make(map[string]string)
		if err != nil {
			return nil, fmt.Errorf("rows Scan failed: %s", err)
		}
		for i, col := range values {
			value := string(col)
			record[columns[i]] = value
		}
		results = append(results, record)
	}
	return results, nil
}

func SelectQueryPro(db *sql.DB, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	return SelectQuery(db, sqlStmt, args...)
}

func ExecSqlNew(db *sql.DB, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var err error
	columns := []string{"lastId", "rowCnt"}
	defer unifiedPrint(&err, nil, sqlStmt, &results, &columns, now, args...)

	res, err := db.Exec(sqlStmt, args...)
	if err != nil {
		return nil, err
	}

	result := make(map[string]string)
	lastId, err := res.LastInsertId()
	if err != nil {
		return nil, err
	}
	result["lastId"] = strconv.Itoa(int(lastId))
	rowCnt, err := res.RowsAffected()
	if err != nil {
		return nil, err
	}
	result["rowCnt"] = strconv.Itoa(int(rowCnt))
	results = append(results, result)

	return results, nil
}

func ExecSql(db *sql.DB, sqlStmt string, args ...interface{}) error {
	_, err := ExecSqlNew(db, sqlStmt, args...)
	return err
}

func ExecSqlCtx(c *gin.Context, dbPtr interface{}, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var err error
	columns := []string{"lastId", "rowCnt"}
	defer unifiedPrint(&err, nil, sqlStmt, &results, &columns, now, args...)

	bqDB, ok := dbPtr.(*bigquery.Client)
	if ok {
		return bqSelect(bqDB, sqlStmt, args...)
	}

	db, ok := dbPtr.(*sql.DB)
	if !ok {
		return results, errors.New("error type dbPtr")
	}

	res, err := db.Exec(sqlStmt, args...)
	if err != nil {
		fmt.Println("###### Error: %s", err.Error())
		return nil, err
	}

	result := make(map[string]string)
	lastId, err := res.LastInsertId()
	if err != nil {
		fmt.Println("###### Error: %s", err.Error())
		return nil, err
	}
	result["lastId"] = strconv.Itoa(int(lastId))

	rowCnt, err := res.RowsAffected()
	if err != nil {
		fmt.Println("###### Error: %s", err.Error())
		return nil, err
	}
	result["rowCnt"] = strconv.Itoa(int(rowCnt))
	results = append(results, result)
	return results, nil
}

func ExecOnlySqlCtx(c *gin.Context, dbPtr interface{}, sqlStmt string, args ...interface{}) ([]map[string]string, error) {
	now := time.Now()
	results := make([]map[string]string, 0)
	var err error
	columns := []string{"lastId", "rowCnt"}
	defer unifiedPrint(&err, c, sqlStmt, &results, &columns, now, args...)

	bqDB, ok := dbPtr.(*bigquery.Client)
	if ok {
		return bqSelect(bqDB, sqlStmt, args...)
	}

	db, ok := dbPtr.(*sql.DB)
	if !ok {
		return results, errors.New("error type dbPtr")
	}

	res, err := db.Exec(sqlStmt, args...)
	if err != nil {
		fmt.Println("###### Error: %s", err.Error())
		return nil, err
	}

	result := make(map[string]string)
	rowCnt, err := res.RowsAffected()
	if err != nil {
		fmt.Println("###### Error: %s", err.Error())
		return nil, err
	}
	result["rowCnt"] = strconv.Itoa(int(rowCnt))
	results = append(results, result)
	return results, nil
}

func ExecSqlPro(db *sql.DB, sqlStmt string, args ...interface{}) (int64, error) {
	ret, err := ExecSqlNew(db, sqlStmt, args...)
	if len(ret) > 0 {
		lastId, err1 := strconv.ParseInt(ret[0]["lastId"], 10, 64)
		if err1 != nil {
			return -1, err
		}
		return lastId, err
	}
	return -1, err
}

// ------------使用事务-----------
func BeginTx(db *sql.DB) (*sql.Tx, error) {
	return db.Begin()
}

func CommitTx(tx *sql.Tx) {
	_ = tx.Commit()
}

func RollbackTx(tx *sql.Tx) {
	_ = tx.Rollback()
}

func ExecSqlTx(tx *sql.Tx, sqlStmt string, args ...interface{}) (int64, error) {
	var lastId int64
	now := time.Now()
	if result, err := tx.Exec(sqlStmt, args...); err != nil {
		fmt.Println("###### Mysql prepare %v failed: %v", sqlStmt, err)
		return -1, err
	} else {
		lastId, _ = result.LastInsertId()
	}
	fmt.Println("\n==>   Sql:%+v \n==>   Args:%+v \n<==   耗时:%+v\n", sqlStmt, args, time.Since(now))
	return lastId, nil
}

func ExecSqlTxContext(c *gin.Context, tx *sql.Tx, sqlStmt string, args ...interface{}) (int64, error) {
	var lastId int64
	now := time.Now()
	if result, err := tx.Exec(sqlStmt, args...); err != nil {
		fmt.Println(c, "###### Mysql prepare %v failed: %v", sqlStmt, err)
		return -1, err
	} else {
		lastId, _ = result.LastInsertId()
	}

	fmt.Println(c, "\n==>   Sql:%+v \n==>   Args:%+v \n<==   耗时:%+v\n", sqlStmt, args, time.Since(now))
	return lastId, nil
}

func unifiedPrint(err *error, c *gin.Context, sqlStmt string, results *[]map[string]string, columns *[]string, now time.Time, args ...interface{}) {
	if *err != nil {
		str := printArgsCtx(sqlStmt, args...)
		if c != nil {
			fmt.Println(c, "%s; \n###### Error: %s", str, (*err).Error())
		} else {
			fmt.Println("%s; \n###### Error: %s", str, (*err).Error())
		}
	} else {
		str, args1 := "", ""
		// 拼接输入信息
		for index, arg := range args {
			if index > 0 {
				args1 += ","
			}
			args1 += fmt.Sprintf("%v (%v)", arg, reflect.TypeOf(arg))
		}
		if len(sqlStmt) > 0 {
			str = fmt.Sprintf("\n==>   SQL: %+v; \n==>   Parameters:%s ", sqlStmt, args1)
		} else {
			str = fmt.Sprintf("\n==>   Parameters:%s ", args1)
		}

		// 拼接输出信息
		str += fmt.Sprintf("\n<==   Columns: %v", strings.Join(*columns, ", "))
		if len(*results) <= 20 {
			str += myPrint(*results, *columns)
		} else {
			str += myPrint((*results)[:20], *columns)
		}
		str += fmt.Sprintf("\n<==   Total: %v; 耗时:%+v", len(*results), time.Since(now))

		if c != nil {
			fmt.Println(c, str)
		} else {
			fmt.Println(str)
		}
	}
}

func printArgsCtx(sqlStmt string, args ...interface{}) string {
	str, args1 := "", ""
	// 拼接输入信息
	for index, arg := range args {
		if index > 0 {
			args1 += ","
		}
		args1 += fmt.Sprintf("%v (%v)", arg, reflect.TypeOf(arg))
	}
	if len(sqlStmt) > 0 {
		str = fmt.Sprintf("\n==>   SQL: %+v; \n==>   Parameters:%s ", sqlStmt, args1)
	} else {
		str = fmt.Sprintf("\n==>   Parameters:%s ", args1)
	}
	return str
}

func myPrint(results []map[string]string, columns []string) string {
	strs := ""
	for k, vmap := range results {
		str := ""
		for index, col := range columns {
			value := vmap[col]
			if value == "" {
				value = "null"
			}
			if index > 0 {
				str += ", "
			}
			str += value
		}
		str = fmt.Sprintf("\n<==   Row[%d]: %s", k, str)
		strs += str
	}
	return strs
}

func prePrint(err *error, c *gin.Context, sqlStmt string) {
	str := fmt.Sprintf("\n==>   Preparing SQL: %+v", sqlStmt)
	if *err != nil {
		if c != nil {
			fmt.Println(c, "%s; \n###### Error: %s", str, (*err).Error())
		} else {
			fmt.Println("%s; \n###### Error: %s", str, (*err).Error())
		}
	} else {
		if c != nil {
			fmt.Println(c, str)
		} else {
			fmt.Println(str)
		}
	}
}

func getSql(stmt *sql.Stmt) string {
	sqlStr := fmt.Sprintf("%+v", *stmt)
	index1 := strings.Index(sqlStr, "query:")
	index2 := strings.Index(sqlStr, "stickyErr:")
	if index1 == -1 || index2 == -1 {
		return ""
	}
	return sqlStr[index1+6 : index2]
}
