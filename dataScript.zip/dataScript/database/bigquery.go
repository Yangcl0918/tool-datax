package database

import (
	"cloud.google.com/go/bigquery"
	"context"
	"e.coding.intlgame.com/partner/dic-framework/zaplog"
	"github.com/gin-gonic/gin"
	"golang.org/x/oauth2/google"
	"google.golang.org/api/iterator"
	"google.golang.org/api/option"
)

// BigQueryConn bigquery 连接
func BigQueryConn(ctx *gin.Context, ident, jsonKey string) (*bigquery.Client, error) {
	if bq := GetBQ(ident); bq != nil {
		return bq, nil
	}

	config, err := google.CredentialsFromJSON(ctx, []byte(jsonKey), bigquery.Scope)
	if err != nil {
		zaplog.ErrorCtx(ctx, "[bigQueryConn]", err)
		return nil, err
	}

	client, err := bigquery.NewClient(ctx, config.ProjectID, option.WithTokenSource(config.TokenSource))
	if err != nil {
		zaplog.ErrorCtx(ctx, "[bigQueryConn]", err)
		return nil, err
	}

	err = pingBigquery(ctx, client)
	if err != nil {
		zaplog.ErrorCtx(ctx, "[bigQueryConn]", err)
		return nil, err
	}

	AddBQ(ident, client)

	return client, nil
}

func pingBigquery(ctx *gin.Context, client *bigquery.Client) error {
	query := client.Query("SELECT 1 as Result")
	iter, err := query.Read(ctx)
	if err != nil {
		zaplog.ErrorCtx(ctx, "[pingBigquery]", err)
		return err
	}

	for {
		var row []bigquery.Value
		err := iter.Next(&row)
		if err == iterator.Done {
			break
		}
		if err != nil {
			zaplog.ErrorCtx(ctx, "[pingBigquery]", err)
			return err
		}
	}
	return nil
}

func BigQueryConnect(ident, jsonKey string) (*bigquery.Client, error) {
	ctx := context.Background()
	config, err := google.CredentialsFromJSON(ctx, []byte(jsonKey), bigquery.Scope)
	if err != nil {
		zaplog.Error("[BigQueryConnect]", err)
		return nil, err
	}

	client, err := bigquery.NewClient(ctx, config.ProjectID, option.WithTokenSource(config.TokenSource))
	if err != nil {
		zaplog.Error("[BigQueryConnect]", err)
		return nil, err
	}

	err = pingBigqueryNew(ctx, client)
	if err != nil {
		zaplog.Error("[BigQueryConnect]", err)
		return nil, err
	}

	return client, nil
}

func pingBigqueryNew(ctx context.Context, client *bigquery.Client) error {
	query := client.Query("SELECT 1 as Result")
	iter, err := query.Read(ctx)
	if err != nil {
		zaplog.Error("[pingBigqueryNew]", err)
		return err
	}

	for {
		var row []bigquery.Value
		err := iter.Next(&row)
		if err == iterator.Done {
			break
		}
		if err != nil {
			zaplog.Error("[pingBigqueryNew]", err)
			return err
		}
	}
	return nil
}
