package remote

import (
	"context"
	"encoding/json"
	"fmt"
	"golang.org/x/oauth2/google"
	"google.golang.org/api/drive/v3"
	"google.golang.org/api/option"
	"google.golang.org/api/sheets/v4"
	"os"
	"strings"
	"test/dataScript/dao"
	"test/dataScript/format"
)

type GoogleRemote struct{}

func NewGoogleRemote() *GoogleRemote {
	return &GoogleRemote{}
}

func (t *GoogleRemote) GetData(param format.FileData, db interface{}) {
	// 创建 Drive API 服务
	filePath, sheetName := "", ""
	for _, v := range param.Content.Read.LinkHeader {
		if strings.Contains(strings.ToLower(v), strings.ToLower("CredentialsFile")) {
			headData := strings.Split(v, ":")
			if len(headData) < 2 {
				continue
			}
			filePath = headData[1]
		}
		if strings.Contains(strings.ToLower(v), strings.ToLower("SheetName")) {
			headData := strings.Split(v, ":")
			if len(headData) < 2 {
				continue
			}
			sheetName = headData[1]
		}
	}
	if filePath == "" || sheetName == "" {
		fmt.Println("google json授权文件路径或sheet name不能为空")
		return
	}
	b, err := os.ReadFile(filePath)
	if err != nil {
		fmt.Println("Unable to read service account file: %v", err)
		return
	}

	// 解析凭证文件
	config, err := google.JWTConfigFromJSON(b, drive.DriveScope)
	if err != nil {
		fmt.Println("Unable to parse service account file to config: %v", err)
		return
	}

	ctx := context.Background()
	client := config.Client(ctx)

	// 获取文档信息 (假设文档的 fileId 已知)
	fmt.Println("谷歌云sheet id：", param.Content.Read.Link)

	// 建立Google Sheets API服务
	sheetsService, err := sheets.NewService(ctx, option.WithHTTPClient(client))
	if err != nil {
		fmt.Println("Unable to retrieve Sheets client: %v", err)
		return
	}
	// 读取表格内容
	resp, err := sheetsService.Spreadsheets.Values.Get(param.Content.Read.Link, sheetName).Do()
	if err != nil {
		fmt.Println("Unable to retrieve data from sheet: %v", err)
		return
	}

	if len(resp.Values) == 0 {
		fmt.Println("No data found.")
	} else {
		var rows [][]string
		rowsByte, _ := json.Marshal(resp.Values)
		err = json.Unmarshal(rowsByte, &rows)
		if err != nil {
			fmt.Println("反序列化表格数据失败: %v", err)
			return
		}
		dao.DataInsert(param.Content.Read.Column, param.Content.Read.DelColumn, rows, param.Content.Write.Table, db)
	}

	return
}
